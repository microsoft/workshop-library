# Intro-to-DevOps-Session

https://app.sli.do/event/hQCFi8fz1fMeyeNQYTuGWW/embed/polls/c0c5d553-bc24-4b40-afea-b6899b09b4ec
